package com.example.yeojun.memoapp;

import com.google.android.gms.maps.model.LatLng;

/**
 * Created by yeojun on 2018. 1. 5..
 */

public class ListItemModel {
    String title;
    String content;
    int weather;
    LatLng latLng;

    public ListItemModel(String title,String content,int weather,LatLng latLng){
        this.title = title;
        this.content = content;
        this.weather = weather;
        this.latLng = latLng;
    }

    public String getTitle(){
        return title;
    }

    public String getContent(){
        return content;
    }

    public int getWeather(){
        return weather;
    }

    public LatLng getLatLng() { return latLng; }

    public void setTitle(String title){
        this.title = title;
    }

    public void setContent(String content){
        this.content = content;
    }

    public void setWeather(int weather){
        this.weather = weather;
    }

    public void setLatLng(LatLng latLng) { this.latLng = latLng; }
}
