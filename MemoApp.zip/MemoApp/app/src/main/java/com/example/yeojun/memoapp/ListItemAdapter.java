package com.example.yeojun.memoapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import java.util.ArrayList;

/**
 * Created by yeojun on 2018. 1. 5..
 */

public class ListItemAdapter extends ArrayAdapter<ListItemModel> {
    Context context;
    private ArrayList<ListItemModel> datas;


    public ListItemAdapter(Context context, ArrayList<ListItemModel> datas){
        super(context,R.layout.layout_memo_item);
        this.context = context;
        this.datas = datas;
    }

    @Override
    public int getCount(){
        return datas.size();
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.layout_memo_item,null);

            ViewHolder holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        }

        ViewHolder holder = (ViewHolder)convertView.getTag();
        TextView tv_Title = holder.tv_Title;
        TextView tv_Content = holder.tv_Content;
        ImageView iv_Edit = holder.iv_Edit;
        ImageView iv_Delete = holder.iv_Delete;
        ImageView iv_Weather = holder.iv_Weather;

        final ListItemModel data = datas.get(position);

        tv_Title.setText(data.getTitle());
        tv_Content.setText((data.getContent()));

        iv_Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Edit Button " + data.getTitle(), Toast.LENGTH_SHORT).show();
            }
        });

        iv_Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Delete Button " + data.getTitle(), Toast.LENGTH_SHORT).show();
            }
        });

        switch (data.getWeather()){
            case 1:
                iv_Weather.setImageResource(R.drawable.apeach);
                break;
            case 2:
                iv_Weather.setImageResource(R.drawable.ryan);
                break;
            case 3:
                iv_Weather.setImageResource(R.drawable.tube);
                break;
            case 4:
                iv_Weather.setImageResource(R.drawable.apeach);
                break;
        }


        return convertView;
    }

}
