package com.example.yeojun.memoapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class EditActivity extends AppCompatActivity {

    Intent sendIntent;
    Intent receiveIntent;
    EditText et_Title;
    EditText et_Content;
    double lat;
    double lng;
    int weather = 1; // 1 = 맑음, 2 = 흐림, 3 = 비, 4 = 눈

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        receiveIntent = getIntent();
        lat = receiveIntent.getDoubleExtra("lat",0.0f);
        lng = receiveIntent.getDoubleExtra("lng",0.0f);

        et_Title = (EditText)findViewById(R.id.et_Title);
        et_Content = (EditText)findViewById(R.id.et_Content);

        Button bt_Cancel = (Button)findViewById(R.id.bt_Cancel);
        bt_Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        Button bt_Complete = (Button)findViewById(R.id.bt_Complete);
        bt_Complete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendIntent = new Intent(EditActivity.this,MainActivity.class);
                sendIntent.putExtra("title",et_Title.getText().toString());
                sendIntent.putExtra("content",et_Content.getText().toString());
                sendIntent.putExtra("weather",weather);
                setResult(RESULT_OK,sendIntent);
                finish();
            }
        });

        AndroidNetworking.initialize(getApplicationContext());
        AndroidNetworking.get("http://apis.skplanetx.com/weather/current/minutely")
                .addQueryParameter("version", "1")
                .addQueryParameter("lat", ""+lat)
                .addQueryParameter("lon", ""+lng)
                .addHeaders("appKey", "91881812-0553-337f-a6dd-b039f902b9e1")
                .setPriority(Priority.LOW)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.d("ye0jun",response.toString());
                        try {
                            JSONObject jWeather = (JSONObject)response.get("weather");
                            JSONArray jMinutely = (JSONArray)jWeather.get("minutely");
                            JSONObject jSky = (JSONObject)((JSONObject)jMinutely.get(0)).get("sky");
                            Log.d("ye0jun",jSky.get("name").toString());
                            String sWeather = jSky.get("code").toString();
                            if(sWeather.equals("SKY_A01") || sWeather.equals("SKY_A02") || sWeather.equals("SKY_A03"))
                                weather = 1;
                            else if(sWeather.equals("SKY_A07"))
                                weather = 2;
                            else if(sWeather.equals("SKY_A04") || sWeather.equals("SKY_A06") || sWeather.equals("SKY_A08") || sWeather.equals("SKY_A10")
                                    || sWeather.equals("SKY_A11") || sWeather.equals("SKY_A12") || sWeather.equals("SKY_A14"))
                                weather = 3;
                            else
                                weather = 4;

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.d("ye0jun",anError.getErrorDetail());
                    }
                });
    }
}
