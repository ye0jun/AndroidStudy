package com.example.yeojun.memoapp;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by yeojun on 2018. 1. 5..
 */

public class ViewHolder {
    public ImageView iv_Weather;
    public ImageView iv_Edit;
    public ImageView iv_Delete;
    public TextView tv_Title;
    public TextView tv_Content;

    public ViewHolder(View root){
        iv_Weather = (ImageView)root.findViewById(R.id.custom_weather);
        iv_Edit = (ImageView)root.findViewById(R.id.custom_edit);
        iv_Delete = (ImageView)root.findViewById(R.id.custom_delete);
        tv_Title = (TextView)root.findViewById(R.id.custom_title);
        tv_Content = (TextView)root.findViewById(R.id.custom_content);
    }
}